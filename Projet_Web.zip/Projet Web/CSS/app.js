const MENUBAR = document.querySelector('.MENUBAR');

MENUBAR.addEventListener('click',show);

function show () {
	// body...
	scripte.style.display ='flex';
}